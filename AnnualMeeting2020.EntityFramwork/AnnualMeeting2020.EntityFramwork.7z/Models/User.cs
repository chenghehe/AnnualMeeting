﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnualMeeting2020.EntityFramwork.Models
{
    /// <summary>
    /// 描述：用户表
    /// 创建时间：2019/11/26 9:51:15
    /// </summary>
    public class User : BaseModel
    {
        public User()
        {
            TicketCount = 6;
        }

        /// <summary>
        /// 名字
        /// </summary>
        [MaxLength(20)]
        public string UserName { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        [MaxLength(20)]
        public string Phone { get; set; }

        /// <summary>
        /// 票数
        /// </summary>
        public int TicketCount { get; set; }

    }
}
