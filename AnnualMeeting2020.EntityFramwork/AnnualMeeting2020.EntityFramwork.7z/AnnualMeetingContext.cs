﻿using AnnualMeeting2020.EntityFramwork.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnnualMeeting2020.EntityFramwork
{
    public class AnnualMeetingContext : DbContext
    {
        public AnnualMeetingContext()
        {

        }

        /// <summary>
        /// 用户
        /// </summary>
        public IDbSet<User> User { get; set; }

        /// <summary>
        /// 演员
        /// </summary>
        public IDbSet<Performer> Performer { get; set; }

        /// <summary>
        /// 投票表，多对多，中间表
        /// </summary>
        public IDbSet<User_Performer> User_Performer { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();

            //添加唯一约束
            modelBuilder.Entity<User_Performer>().HasIndex(x => new
            {
                x.User,
                x.Performer,
            }).IsUnique();
            modelBuilder.Entity<User>().HasIndex(x => new
            {
                x.UserName,
                x.Phone,
            }).IsUnique();

        }
    }
}
